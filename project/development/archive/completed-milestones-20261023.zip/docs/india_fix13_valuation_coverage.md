# India Fix 13 — valuation coverage review

Reviewed 23 October 2026. This completes the coverage review, not universal price coverage. No production code, rate, template, configuration, API or dashboard change is justified by the available India sample. The running service stays active throughout this read-only review.

## Available source and current coverage

There is one unique India shipment PDF, `26S5196-D.pdf`, present in both examples and incoming with identical bytes. It has three pages; packing details are on pages 2–3. Duplicate copies and renamed/synthetic test files are not additional unseen shipments.

| PDF goods group | PDF quantity basis | Approved USD unit estimate | Calculated line value |
|---|---|---:|---:|
| Composition/width-labelled woven fabric | Six colors × 63 YDS = 378 YDS | 0.20/YDS | 75.60 |
| Zipper | 5 + 35 + 5 + 15 + 5 = 65 PCS | 0.10/PCS | 6.50 |
| Printed fabric cuttings | Three colors × 1 SET = 3 SETS | 0.10/SETS | 0.30 |
| Calculated total | | | **82.40** |

All **3/3 extracted goods groups** have an approved category/unit rate; no current India group lacks a value. These are the approved standing estimates from Stage 4B, not prices printed in this PDF. Replaying valuation on a separate copy with estimated prices/amounts removed reproduces the same results and preserves source descriptions, quantities, units, HS and provenance. No manual expected invoice is needed or read.

The handwritten cuttings subtype remains the previously documented printed-description fallback. That extraction uncertainty is not a missing valuation rate. Three priced groups do not establish overall extraction accuracy or coverage for new shipments.

## What remains deliberately unpriced

India's rate list contains only fabric/YDS, zipper/PCS and fabric swatch/sample/cutting/SETS. Examples outside it include:

| Category or unit | Why no India estimate is added |
|---|---|
| Fabric cards, swatches priced per piece, trim cards and blanket packs | Different item/unit pairs; the SETS rate cannot be reused automatically |
| Zipper clips, moulds, buttons, snaps and rivets | Different categories from zippers; Bangladesh estimates do not establish India rates |
| Garments per piece | No India garment pricing example/standing rule in the available source |
| Lace per yard | Not the approved generic fabric category |
| Fabric in MTRS, rolls or packs | No approved price for that unit; no meter/yard or roll-length conversion is inferred |
| Threads/cones or unknown goods | No approved regional category/unit rate |

A comparison of the broader Bangladesh dataset finds 34 distinct description/unit pairs without an India fallback rate. They are **comparison-only examples**, not 34 missing rows in the India shipment. Their exact inventory is in `coverage-audit.json`. No Bangladesh category/rate is silently promoted into the India list, and no shipment total is reverse-engineered into new prices.

No new rate has been added. Additional rates should be explicit category/unit business assumptions, supported by a new source example or a user-approved standing schedule. The existing `valuation_rates.json` remains the only rate configuration file; no new service, dependency or configuration layer is introduced.

## Checked behavior

- A labelled USD source price can value an otherwise unknown category. An explicit source amount remains authoritative without inventing a unit price, including when quantity/unit is absent. Disagreeing source price × quantity and declared amount are preserved under the existing PDF-first policy.
- Without source money, unmatched categories/units remain unpriced. A mix of priced and unpriced lines has no calculated shipment total. An explicitly declared source total is preserved even if individual lines cannot all be priced; it is not a partial estimated sum.
- Missing/invalid quantities and incomplete page coverage do not produce a complete estimated total. Zero quantity without a source amount remains unestimated under the current positive-quantity calculation rule. Explicit zero source prices/amounts are preserved.
- Line and complete calculated India totals use Decimal half-up cents. A 1.25 × 0.10 line becomes 0.13. Bangladesh's existing whole-dollar total rule is unchanged.
- Parser spelling aliases such as YD/YARD/YARDS, PC/PIECE/PIECES and SET normalize to the existing YDS/PCS/SETS units. This is spelling normalization, not unit conversion. No gross/piece, pack/set, roll/yard or currency conversion is assumed.
- Non-USD sources do not receive USD fallback rates. Existing India export safeguards still reject unsupported currency rather than relabel it as USD.
- Fix 11's manual editor accepts per-invoice user values, preserves source amounts on non-monetary corrections, and does not turn those corrections into future standing rates.

No review/validation message is added to an invoice. Existing blanks and dashboard explanations remain the product behavior.

## Verification and outcome

Evidence: `reports/india_fix13_20261023/` contains source hashes, retained packing text, pricing replay, comparison inventory, **37 passing synthetic boundary probes**, **35 passing focused valuation/source-price/currency/edit tests**, and exact replay of all **20 Bangladesh valuation results**. The last full regression remains Fix 12's 438 passing tests; it is not rerun for a documentation-only review. Source OCR/model inference, fresh-PDF acceptance and native print are not repeated because no runtime or workbook changes are made.

Protected production file hashes and history are compared before/after the review, alongside live dashboard checks. Documentation is packaged in a manifest-verified release. No service stop/restart, migration, production reprocess or destructive restore is needed. Rollback is documentation-only; runtime behavior and rates remain identical to Fix 12.

Fix 13 is reviewed and complete under the approved policy that unsupported categories remain unpriced. India folder watching stays disabled. Fix 10's additional unseen-PDF validation is still pending. Next, after user approval, is Fix 14: implement and verify regional folder intake/routing, keeping Jordan disabled and explicitly carrying forward the outstanding real-PDF validation limit.

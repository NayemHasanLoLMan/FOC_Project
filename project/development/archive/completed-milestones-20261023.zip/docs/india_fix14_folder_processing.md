# India Fix 14 — regional folder processing

23 October 2026. Scope: enable India intake through the existing scanner, worker, database and dashboard. No extraction, valuation, template, OCR/model or invoice-layout change; no dependency or second worker is introduced. Jordan intake remains disabled.

## Result and operation

The current installation enables `incoming/india` → `output/india` alongside Bangladesh's existing pair. Use **System → Processing settings** to enable/disable new India intake and change either India folder. The base release configuration remains Bangladesh-only until India is explicitly configured/enabled. The combined launcher loads persisted settings; standalone maintenance commands still use their explicit configuration file.

India's region is recorded when accepting the PDF and cannot be reassigned. Both countries use the same stable-file validation, source snapshots, collision-safe versioned publication, retry and image evidence. A missing India inbox degrades scanner health without blocking Bangladesh. Same filenames in separate folders remain separate jobs; rescanning/restarting the same path/content does not create duplicates. A conflicting source destination is still rejected by the converter.

Each new attempt records its actual regional output root. Prepared saves and historical downloads retain that location after settings changes or restart. Legacy receipts still use their original recorded global output root. Disabling India affects new intake only; accepted jobs/retries continue. Folder pairs cannot overlap, use protected application/reference/cache paths, traverse redirected paths or be reassigned to another country with existing history. India folders cannot be removed while India history remains; disable intake instead.

Clear data recoverably archives both currently configured output folders, the shared artifacts and database, then rediscovery accepts retained PDFs from enabled inboxes exactly once. India output remains included when new intake is disabled. Reset rolls back both countries if a move fails. Separate alternate-volume recovery records preserve both output locations. Earlier output locations from previous settings are intentionally retained, following existing reset behavior. No production reset was used during QA.

## Verification

- **454 tests passed**, including **16 focused routing tests**. They cover immutable country routing, identical basenames, repeated scans/restart, disabled/missing inboxes, country-specific templates/publication/download/preview, locked-save recovery without OCR after a folder change, failed-job retry, versioned manual editing without OCR, old/new settings compatibility, path/reassignment protection, mixed-country clear/rediscovery/rollback, two alternate-volume archives, development isolation and a combined-launcher restart.
- The real three-page India PDF passed isolated intake/conversion/publication with exact existing model/OCR caches. No model inference or manual reference read was made in that warm test. The workbook has three groups: 378 YDS fabric, 65 PCS zippers and 3 SETS fabric cuttings; 7 packages, explicit gross 106 kg, invoice S/5196/26, date 13-Oct-2026 and USD 82.40.
- All **20 retained Bangladesh invoices** and the retained India workbook were regenerated privately and matched their previous populated values, cell types and number formats. Production originals were preserved.
- Two isolated browser form saves disabled/re-enabled India, created custom paths and persisted all settings. The main System page displays India enabled and Jordan disabled. API/OpenAPI/Postman documentation and build boundaries are checked with the existing project tests.
- The main service independently processed all three pages with fresh OCR and local model reads, then published `output/india/26S5196-I.xlsx`. Its entire structured result equals the isolated result. The cold run took 17.3 minutes; Ollama reported zero GPU memory in use.
- Main-service publication, old-history/file preservation, retained Bangladesh parser/valuation replay and live HTTP checks are recorded in `reports/india_fix14_20261023/verification.json`. Exact-input warm evidence is separate from the first production OCR/model run. Do not infer cold performance from the warm test.

Evidence and rollback bundle: `reports/india_fix14_20261023/`, including the verified pre-change backup, regression/focused logs, isolated PDF acceptance, 21-workbook comparison, browser-settings verification, activation record, main-service verification and release manifest checks.

## Limits and next step

There is still only **one unique real India shipment**. Renamed copies and synthetic boundary tests are not unseen shipments; **Fix 10 remains pending**. The unreadable handwritten subtype retains its existing printed fallback, unsupported currency still fails safely, unsupported facts remain blank and unmatched goods/units remain unpriced. This update enables routing; it does not establish universal extraction accuracy. Generous model limits are unchanged; first-time OCR/vision remains hardware-dependent.

Native Excel printing and actual Windows sign-out/reboot are not repeated for this routing-only update. Full India release acceptance is **Fix 15**, after user approval. Jordan work remains a later separately approved stage.

To pause only new India intake, disable it in System and retain its folder pair. For a full rollback, stop/drain the managed service, preserve the new India job/output/evidence and current settings separately, then restore the matching pre-Fix-14 source/frontend/configuration and database/artifact/output snapshot. Do not combine the old database with newer receipts or move historical outputs by editing paths. Restart the prior version with its matching settings; no schema migration was introduced.

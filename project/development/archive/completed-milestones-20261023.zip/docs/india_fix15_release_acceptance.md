# India Fix 15 — available-sample release acceptance

23 October 2026. **Acceptance passed for the current India sample and the tested pipeline boundaries.** Additional unseen India PDFs remain unavailable, so Fix 10 is still pending. This is not universal extraction certification or completion of the separate Windows reboot/production Stage 8 gate. Jordan remains disabled.

No production Python, frontend, template, rate, model, vision-limit or folder-setting change was needed. This update adds acceptance evidence and documentation. The main service remains enabled on port 8080 with Bangladesh and India intake.

## Checks and results

| Check | Result |
|---|---|
| Full regression | 454 tests passed; installed dependencies pass `pip check` |
| Real India PDF through the folder queue | New isolated intake of all three source pages, real converter, correct India template/output, one job, no duplicate on rescanning |
| Cached versus fresh processing | This acceptance used exact existing OCR/model caches, with no new inference. Fix 14 independently completed fresh OCR and three local image reads in 17.3 minutes on CPU; its entire structured result matches the warm run |
| India source-backed result | S/5196/26, 13-Oct-2026, destination Chennai/India, cartons T01-T07, 7 packages, explicit gross 106 kg, three goods groups and USD 82.40 |
| Goods | 378 YDS fabric, HS 55132900, USD 75.60; 65 PCS zippers, USD 6.50; 3 SETS fabric cuttings, USD 0.30 |
| Browser editing | Two synthetic saves in an isolated queue: added port/terms and changed an HS code, then changed quantity/rate and added a row. Source and old downloads remain unchanged. HS leading zeros survive. USD 1.005 rounds to 1.01 and the edited test total is 7.91. No OCR/model call during edits |
| Preview/download | Original and edited versions preview correctly; downloads match retained SHA-256 receipts and use the plain invoice filename. Production invoice remains USD 82.40; synthetic QA values never entered production |
| Recovery | Real cached India conversion with simulated locked save, interrupted prepare commit and interrupted completion after publication. A restarted worker, with changed current folder settings, reused each recorded original destination, produced one output and made no repeat conversion |
| Native Excel print | 24 PDF exports, 25 pages: all 21 production invoices, two isolated edited versions and one current-template Bangladesh review. All 105 goods appearances, dates, consignees and totals are present; no blank pages, formula errors or intervention messages. India and its two edited variants are one page each |
| Visual print review | All 25 pages rendered/reviewed; India and current Bangladesh master inspected at larger size. Historical Bangladesh 5193 uses two pages with repeated goods headings and a final total. No new clipping observed |
| Bangladesh preservation | All 20 parser and valuation replays match the retained baseline. All 21 production workbooks match retained populated values, cell types and number formats and pass application publication verification. Original output bytes remain unchanged |
| Historical presentation | All 20 saved Bangladesh invoices retain their earlier table/total style. The current master produces the newer bordered table and clean total. This existing difference is documented in the prior layout review; history is preserved, while future invoices inherit the current master |
| Images and dashboard | 18 crop/highlighted-page endpoints pass across production Bangladesh/India and the edited private job. Fifteen main page/API/editor/preview/download routes pass. Original readings remain available after both manual edits |
| Runtime data | Verified pre-acceptance backup; protected file hashes and every existing job/attempt/event/control/admin row preserved. Main queue remains 21 completed jobs / 21 attempts, with healthy scanner and worker and no duplicate intake after managed restart |
| Production package | Manifest-verified source ZIP; no tests, reports, runtime, cache, environment, source PDFs or expected workbooks inside. All seven packaged CLI help commands pass. Its extracted converter processes the copied India PDF with external installed dependencies/exact caches and no manual-reference access; result equals production |

Evidence is isolated under `reports/india_fix15_20261023/`: regression log, verified rollback archive, real queue/browser records, workbook comparisons, native PDFs/page renders, recovery records, production preservation, package smoke and release verification. Test edits, simulated failures and print copies are not production shipments.

## Supported differences and limits

- PDF facts retain priority: source date is 13-Oct rather than the manual reference's 14-Oct; fabric width is 53 inches rather than the reference's 53 cm. Printed FABRIC CUTTINGS remains the fallback for the unresolved handwritten subtype. Gross is the explicit estimated 106 kg.
- Departure origin/date/mode, discharge port and shipment terms remain empty where unsupported under the approved PDF-only rules. Reference CPT/Chennai-port values are not standing defaults. No unsupported net weight is printed. Source-supported prices/currency retain priority; unmatched categories/units stay unpriced, and unsupported India currency fails safely.
- There is one unique real India shipment. Renamed copies, cached replays, manual edit fixtures and synthetic tests do not establish unseen-PDF accuracy. **Fix 10 stays open.**
- Cold CPU OCR/vision can take many minutes. The roughly five-second warm replay is not a fresh-document throughput claim. No hardware/model change or reduced timeout/token limit was introduced.
- Native Excel PDF export was tested; a physical printer, Windows sign-out/reboot, fresh-PC installation and fully offline dependency/model provisioning were not tested. The separate production Stage 8 gate remains open.

## Operating and release decision

The current installation supports Bangladesh and controlled India use through one launcher. Existing settings persist across restart; configure an explicit India folder pair and enable intake in System on a new deployment. The packaged base configuration remains Bangladesh-only until India is deliberately enabled. Models, dependencies, runtime history and caches are provisioned separately; the ZIP is a source release, not a standalone installer.

Fix 15's available-sample acceptance is complete. The next checklist point is **Stage 5 — Jordan master and expanding goods layout**, only after user approval with the pending India validation and accepted fallback stated. Do not enable Jordan extraction/intake implicitly. Its known page-recipient/origin/rate decisions remain for its own stages.

Rollback of this acceptance update is documentation-only: use the prior Fix 14 bundle/documentation; runtime behavior is identical. Keep the verified Fix 15 matching database/artifact/output backup for recovery. Stop/drain before any full state restore, and never mix old database rows with newer artifacts or historical paths. See [operations](operations.md) and [build](build.md).

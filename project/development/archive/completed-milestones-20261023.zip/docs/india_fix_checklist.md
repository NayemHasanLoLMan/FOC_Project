# India fixes before the next regional stage



Created 22 October 2026 from the India audit. Complete one task at a time, report the checks and obtain user approval before starting the next task. Do not combine extraction, valuation and dashboard changes in one update. Production conversion must never read manual reference invoices.



Current baseline: the India sample has 378 YDS fabric, 65 PCS zippers, 3 SETS printed fabric cuttings, 7 packages, explicit gross 106 kg and USD 82.40. Fixes 1–9 and 11–15 are complete/reviewed for the available sample. Fix 14 enables separate India intake/output through the existing pipeline; the main queue now has 20 unchanged Bangladesh jobs and one completed India job. All 454 tests pass, including 16 focused routing/recovery/settings/reset checks. All 20 Bangladesh parser/valuation replays and 21 retained workbook value/type/format comparisons pass. Jordan intake remains disabled. Fix 10 still needs unseen India PDFs; Fix 15 available-sample release acceptance passed, including native printing and real-PDF recovery; the next stage is Jordan master/layout after user approval. Unseen India validation and the separate reboot gate remain pending.



## Fix sequence



23 October layout review: while additional PDFs are unavailable, the user requested a full existing-sample reference comparison and shared Bangladesh/India goods-table styling. See [comparison and layout review](invoice_layout_review.md). This presentation update does not complete Fix 10 or enable India watching/editing. Unsupported shipment terms, discharge port and departure date remain blank under the confirmed PDF-only rule.



- [x] **1. Extract printed unit prices and item amounts.** Completed 22 October 2026; [acceptance report](india_fix1_source_prices.md). Recognize explicitly labelled source price/amount columns before applying approved estimates. Verify a source USD 3.00 rate and USD 30.00 amount survive parsing and export; absent prices still use approved rates. Preserve source totals and Bangladesh behavior.

- [x] **2. Detect and respect source currency.** Completed 22 October 2026; [acceptance report](india_fix2_currency.md). Retain an explicit PDF currency; never apply USD estimates to another currency or silently print its amounts as USD. Verify EUR and USD cases, conflicting declarations and absent currency under a documented policy. Reject unsupported export safely rather than overwrite an existing invoice.

- [x] **3. Improve invoice-number extraction.** Completed 22 October 2026; [acceptance report](india_fix3_invoice_number.md). Read the relevant PDF area using existing OCR/selective vision and best-effort selection. Verify original and renamed PDFs independently; retain candidate evidence and document failures. Keep the approved recognizable-filename fallback as a fallback, without shipment-specific answers.

- [x] **4. Make header reading tolerate equivalent label layouts.** Completed 22 October 2026; [acceptance report](india_fix4_headers.md). Support same-line and adjacent-line dates, shipping marks and destination values without relying on one exact line break or colon, including adjacent OCR table cells. Labelled boundaries exclude unrelated dates, addresses and notes; conflicts stay blank. Explicit export date priority and the approved latest-labelled-packing-date fallback are preserved.

- [x] **5. Fix goods continuation across tables/pages.** Completed 22 October 2026; [acceptance report](india_fix5_continuation.md). Carry product context only across consecutive compatible goods tables beginning with a supported color row and matching explicit quantity units. Reset at new products/styles, unclear identities/boundaries and incompatible quantities. A zipper heading with 2 PCS and next-page color row with 1 PCS becomes the correct 3 PCS group with retained source references. Money remains row-specific; supported HS inheritance was added in Fix 7.

- [x] **6. Verify every printed India header before publication.** Completed 23 October 2026; [acceptance report](india_fix6_header_verification.md). Compare invoice number/date, consignee/address and rendered identifiers, marks, destination, both carton locations, packages/gross and supported port/terms against structured data. Check literal readable formats, active/visible invoice sheet, header print bounds and hidden rows/columns. Incorrect/stale values fail; legitimate blanks and zero stay valid. Direct/queue failure tests preserve prior published outputs.

- [x] **7. Preserve HS codes through supported continuations.** Completed 23 October 2026; [acceptance report](india_fix7_hs_continuation.md). Reuse supported product/color links to extend an earlier explicit HS code into blank continuation cells. Conflicting codes, unreadable declarations and ambiguous HS columns block inheritance; readable direct values remain. No backward fill, unrelated-product fill or classification inference. Leading zeros, coded-row provenance and row-specific money are preserved.

- [x] **8. Review the unresolved handwritten description.** Reviewed 23 October 2026; [assessment](india_fix8_handwriting_review.md). Three fresh local-reader comparisons with original/highlight-separated focused crops completed normally but returned SMARTONES/SMARTOMES variants. No reliable subtype improvement was established. Retain printed FABRIC CUTTINGS, 3 SETS; handwriting remains unresolved. No production code/settings change or reference-forced replacement was made. This completes the review using the checklist's supported-fallback policy.

- [x] **9. Review vision runtime and unnecessary calls.** Reviewed 23 October 2026; [runtime assessment](india_fix9_runtime_review.md). Exact cached replays took 0.072–0.079 seconds median versus the same requests' earlier 47–253 seconds fresh; all nine replays and three real warm queue attempts made zero new inference calls. Cache invalidation/retry/negative-result contracts passed. Existing selective calls, evidence and generous limits are retained; no unsupported skip, model switch or production code change was justified. Cold new-document processing remains model/hardware-bound.

- [ ] **10. Validate on additional unseen India PDFs.** Cover renamed sources, multiple pages, continued goods, header variations and priced/unpriced cases using available real shipments. Separate synthetic boundary tests from real-PDF accuracy. Do not claim universal accuracy from the existing single example. If more PDFs are unavailable, keep this validation explicitly pending.

- [x] **11. Support safe India manual editing.** Completed 23 October 2026; [acceptance report](india_fix11_manual_editing.md). Existing versioned editing now supports India HS, port/terms and regional header fields. Country/template/currency/source are protected; original files and image evidence remain available. Source amounts survive HS/description-only changes; monetary changes use cent totals. Nine focused queue/API tests, two isolated browser saves, native Excel print, recovery/publication-failure tests and the 432-test regression gate passed. Bangladesh editing and extraction remain stable; India watching stays disabled.

- [x] **12. Make India dashboard details match the invoice.** Completed 23 October 2026; [acceptance report](india_fix12_dashboard_details.md). India now shows HS, destination/carton references and supported port/terms, with IEC/PAN/GST and saved-currency labels. Net weight and its legacy missing-value note are hidden from the India view; raw records remain intact. Six focused tests and 438 regression tests passed. All 20 BD detail pages match their previous content/structure/links, and three original crop/highlighted-page pairs remain available. No extraction, workbook, edit-contract or watching change.

- [x] **13. Review valuation coverage for new goods/units.** Reviewed 23 October 2026; [coverage report](india_fix13_valuation_coverage.md). The single unique India PDF has 3/3 groups priced at the existing approved rates, totalling USD 82.40. No new rates or runtime changes are justified. Unsupported category/unit pairs remain unpriced without source money; incomplete estimated totals stay blank while declared source totals remain authoritative. Thirty-seven synthetic probes, 35 focused tests and all 20 BD valuation replays passed. Broader BD comparison categories are inventoried separately, without adopting their rates for India. This completes the review, not universal price coverage.

- [x] **14. Enable and verify India folder processing.** Completed 23 October 2026; [acceptance report](india_fix14_folder_processing.md). The existing scanner/worker now supports explicit India folders and immutable job region, regional template/output routing, recorded-root recovery/downloads, compatible seven/ten-field settings, development isolation and recoverable mixed-country reset. Sixteen focused tests and all 454 regression tests passed; actual India intake/publication and managed restart preserve one India job and all 20 Bangladesh jobs/files. The main result equals the isolated PDF result, with no runtime manual-reference dependency. Jordan stays disabled. Fix 10 remains explicitly pending; routing activation does not claim unseen-document accuracy.

- [x] **15. Complete India release acceptance and documentation.** Completed 23 October 2026 for the available sample; [acceptance report](india_fix15_release_acceptance.md). All 454 tests and dependency checks pass. Real cached India intake, two isolated browser saves, preserved downloads/images, three real-PDF recovery fault points and 24 native Excel PDFs (25 pages) passed. All 20 Bangladesh parser/valuation results and all 21 original output bytes/history remain unchanged; older saved Bangladesh styling is preserved while the current master is verified separately. The manifest-checked extracted production package converts without test/reference folders. No runtime/template/rate/settings change. Fix 10 unseen-PDF validation, physical printer/fresh-machine tests and the separate Windows reboot gate remain open; this is not universal accuracy certification.

- [ ] **16. Next stage: Stage 5 — Jordan master and expanding goods layout.** Start only after the India checklist has been reviewed and the user approves moving on. Any pending validation or accepted fallback must be stated explicitly before that decision. Preserve Bangladesh and India behavior while implementing Jordan separately.



## Acceptance for every code update



Use the existing modules/dependencies and the smallest complete change. Add a focused test for new logic, run relevant checks and the required regression gate, verify the affected invoice/output against the PDF, and preserve Bangladesh results. Test in isolated folders; do not reset or overwrite production data for QA. Keep human-review/validation messages off the invoice itself; unsupported fields remain blank unless a supported fallback applies. Record what changed, evidence, limitations and rollback details before the next task.



## Supported differences to preserve



The current source date is 13-Oct-2026, width is 53 inches and gross weight is the explicit estimated 106 kg. Do not replace these with unsupported manual-reference values or force the packing-weight sum to equal the declaration. The unreadable handwritten subtype may retain the readable printed description. Source prices/currency take priority once correctly extracted; the approved India approximate rates and cent rounding remain the fallback for supported USD categories.








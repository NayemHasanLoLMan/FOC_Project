# Continuous PDF-to-invoice pipeline and admin dashboard

Status: Stage 7 is approved and implemented; see [Stage 7 operation and acceptance](pipeline_stage7.md). Stage 8 awaits separate user approval. Implement one stage at a time, prove its acceptance checks, and ask the user before proceeding. Existing single-file/batch conversion and BD invoice contents/formatting remain supported. See the [Stage 1](pipeline_stage1.md), [Stage 2](pipeline_stage2.md), [Stage 3](pipeline_stage3.md), [Stage 4](pipeline_stage4.md) and [Stage 5](pipeline_stage5.md) acceptance reports.

## Outcome and boundaries

Watch one configured local folder for incoming PDFs, process stable arrivals automatically, and save their invoices using the shared BD template. A local web dashboard shows queue counts, component health, job stages, issues, output files and source/model evidence. Review information belongs in the dashboard, never as validation or intervention text on an invoice. Production never reads manual expected outputs.

Start with one extraction worker on this PC. The existing vision allowance (4,096 output tokens, 8,192 context and two-hour request timeout) stays unchanged. Long inference must not block folder scanning, dashboard responses or service heartbeats. The PC must be awake; stopped services discover missed arrivals on their next scan.

## Original starting point (historical)

| Area | Exists now | Addition needed |
|---|---|---|
| Conversion | `src/foc_extractor/pipeline.run`, PaddleOCR, bounded Qwen3-VL fallback, supported parsing/valuation | Call the same converter from a worker; do not rewrite extraction |
| Invoice appearance | Shared `templates/BD_template.xlsx`; style inheritance; atomic workbook save | Use the same master for every queued job |
| Batch tracking | A JSON manifest for one batch invocation | Durable queue, attempt history, ownership and restart recovery |
| Processing evidence | OCR words/tables/transforms; package/weight evidence; model answer cache; workbook audit | Per-job events, consistent provenance and links to review artifacts |
| Images | PDF pages/crops rendered in memory; some development images in reports | Save exact model-input crops during processing; render source pages on demand |
| Progress | Console messages and final result | Structured stage/page events, elapsed times and independent heartbeats |
| Administration | CLI commands | Local dashboard and guarded queue controls |

## Minimal architecture

```mermaid
flowchart LR
    A[Configured incoming folder] --> B[Polling scanner and file-readiness checks]
    B --> C[(SQLite jobs, attempts and events)]
    C --> D[One extraction worker]
    D --> E[Existing PDF-to-invoice converter]
    E --> F[Versioned Excel output and evidence]
    D --> C
    E --> C
    C --> G[Local admin web dashboard]
    F --> G
```

- Python `pathlib`, `hashlib`, `sqlite3`, `logging` and existing image/PDF libraries cover discovery, persistence and artifacts. Polling avoids a new file-watcher dependency; start with a five-second scan interval and tune only if needed.
- A small Flask app with plain HTML/CSS/JavaScript is sufficient for the dashboard. Use Waitress for deployment on Windows. These would be the only new web dependencies; add them at the dashboard stage. No frontend build system or external queue/database service is needed.
- Keep scanning/coordination and the extraction worker separate so lengthy OCR/model work cannot freeze administration. The web app reads persisted state; opening a browser never starts another worker.
- Bind the dashboard to `127.0.0.1` initially. LAN/multi-user access is a separate scope requiring authentication and deployment decisions.
- Use Windows Task Scheduler for hidden background startup/restart on this PC initially. Display this accurately as a managed background task, not as a native Windows Service. Decide startup account and Ollama startup together before enabling unattended operation.

References: [Flask deployment](https://flask.palletsprojects.com/en/stable/deploying/) and [Waitress on Windows](https://flask.palletsprojects.com/en/stable/deploying/waitress/).

## Sequential implementation checklist

| Stage | Deliverable | Acceptance gate |
|---|---|---|
| 1 | Configuration and durable job store | Queue/attempt state survives restart; duplicate claims are prevented; existing CLI behavior and tests are unchanged |
| 2 | Folder scanner and safe intake | New stable PDFs queue automatically; partial copies do not run; unchanged files do not loop; changed files become new versions |
| 3 | One background extraction worker | Real PDFs produce invoices through the existing converter; failures are isolated; interrupted work recovers; no existing invoice is overwritten accidentally |
| 4 | Structured processing events and review artifacts | Dashboard data distinguishes OCR, model calls, cache reuse, acceptance/rejection and issues; exact model-input crops can be reviewed |
| 5 | Read-only web dashboard | Health, counts, job history/detail, issues, PDFs, invoice downloads and evidence work while OCR/VL is busy |
| 6 | Admin controls and recovery | Pause/resume, selected retry and save retry work without duplicate attempts or invoice damage |
| 7 | Unattended Windows startup | Background startup, failure restart, single-instance protection and Ollama dependency reporting work without a browser |
| 8 | End-to-end acceptance and operating guide | Restart/copy/duplicate/locked-file/model-failure cases pass; BD regression and unseen-PDF checks pass; recovery instructions are documented |

Stages 1–7 provide durable intake/processing, review evidence, guarded local admin controls and current-user background startup. The unified run_system.py command starts the system. Final acceptance remains Stage 8. The user explicitly requires approval before each next stage.

### Stage 1 — configuration and durable state

- [x] Added `pipeline_config.json` for incoming/output/state/artifact paths, a five-second scan interval and the existing model choice. Paths resolve relative to the config file, independent of the working directory. Defaults use `project/incoming`, existing `project/output` and ignored `project/runtime` state/artifacts; actual production intake still needs confirmation. Examples remain tests. No watcher is enabled.
- [x] Added a SQLite-backed job/attempt/event store. Source identity/hash and snapshot reference, states, timestamps, outputs, errors, issues and worker ownership persist. Transactions are short; processing is not performed by the store.
- [x] Added attempt metadata snapshots for configuration, template/rates/application fingerprints and Python/application versions. Actual model digest remains explicitly unknown until processing resolves it in a later stage. Configuration changes do not requeue completed work.
- [x] Defined waiting-for-file, queued, running, waiting-to-save, completed, failed and interrupted states. Queue/claim/finish/interruption/retry history is tested. Stage 2 now stores waiting-for-file readiness separately in intake records; Stage 3 now implements waiting-to-save transitions. Issues remain separate from lifecycle state.
- [x] Existing converter/CLI files remain byte-for-byte unchanged. Baseline 128 tests passed; all 142 tests now pass, including 14 new state/configuration tests. All 78 protected files and the complete reference comparison remain unchanged; 20 invoices/66 source pages/89 goods rows pass output checks.

### Stage 2 — stable folder intake

- [x] Added continuous polling plus `--once`, case-insensitive PDF extensions and existing/later arrival discovery; temporary/hidden/owner files, links, non-files and subfolders are ignored.
- [x] Readiness uses stable metadata and content hash across interval-separated observations. The snapshot is hash-verified, source bytes checked again, and all PDF pages loaded. Missing EOF, password requirements and structural repair are recorded as rejected intake. Atomic producer rename is supported/preferred; stability is not a completion guarantee.
- [x] Preserved the original basename in source-identity/content-versioned input snapshots.
- [x] Same identity/content is idempotent across restart; another basename remains separate and its queued event records related same-content jobs.
- [x] Changed bytes become a new version without altering earlier snapshots/jobs or deleting source PDFs. Missing sources keep accepted snapshots/jobs intact.
- [x] All 159 tests pass, including 17 intake cases and schema migration. Real CLI intake queued all 20 examples in an isolated database, verified all snapshots and created no duplicate jobs after restart. All 81 protected files and the reference comparison are unchanged. Default empty inbox is created/scanned; no scanner remains running. See [Stage 2 details and limits](pipeline_stage2.md).

### Stage 3 — durable worker and output publication

- [x] Claim one queued job transactionally; prevent two worker instances from claiming the same attempt. Give the coordinator and worker independent heartbeats.
- [x] Call the existing converter against the immutable snapshot, preserving the original filename and current template/source policies. Use a job-specific working output directory to prevent collisions.
- [x] Publish completed work atomically. Keep compatible invoice filenames for the first version and a deterministic version suffix/directory for later collisions; never replace an unrelated or historical invoice silently.
- [x] If Excel locks a destination, retain the already generated workbook and mark waiting to save. Retry publication without rerunning expensive OCR/VL.
- [x] On restart, reconcile persisted attempts and completed files. Interrupted jobs can replay from the snapshot using caches. Use recoverable attempts and idempotent publication; do not promise that a crash can never repeat computation.
- [x] Isolate one PDF's failure. Ordinary conversion failures stop that job; unprepared crash recovery is limited to three interrupted attempts. Record lifecycle errors; detailed extraction-stage events remain Stage 4.
- [x] Test successful conversion, worker crash, output-lock recovery, same-name versions, duplicate worker launch and disk/write failures. Compare invoice facts/styles with the baseline.

All 177 tests pass. The real worker completed all 20 example PDFs (66 pages, 89 goods rows) with the same invoice values/styles and reference scores. Restart created no extra attempts. All 82 protected files are unchanged; default state is schema 3 with zero production jobs, and both components are stopped. See [Stage 3 acceptance and operating limits](pipeline_stage3.md).

### Stage 4 — truthful processing evidence

- [x] Add optional structured observation to the shared pipeline and its OCR/quantity/package/weight/model steps. Existing callers that do not request observation must retain their behavior and return type. Do not scrape console text as the authoritative status API.
- [x] Record job/attempt, stage, page/region, method, elapsed time, original OCR reading, candidate/final value, accepted/rejected outcome and reason. Separate explicit source values, directory fallback, derived packing sums and approved valuation assumptions.
- [x] Separate **VL attempted**, **VL contributed an accepted value**, **fresh inference**, and **cached model answer**. A cache hit still uses model-derived information. Do not label a job OCR-only simply because no fresh model call ran.
- [x] Distinguish rejected answers, unavailable model, invalid/truncated response and no model needed. Persist events for failures as well as successes. Record model name/digest, request settings and available timing/token metrics; missing telemetry stays unavailable.
- [x] Save the exact PNG bytes sent to the model, including supplied KG headings, resizing/composites and source page/coordinates/transforms. Saving only a new approximation of the region is insufficient for review. Reuse content-addressed artifacts where appropriate.
- [x] Provide tested on-demand source thumbnails/highlighted regions using the retained coordinate transform; displaying them in the web UI belongs to Stage 5. Generate full-page previews on demand rather than storing every page at multiple resolutions. Preserve field-to-source links through grouped goods rows where they already exist; do not invent provenance where it is absent.
- [x] Keep artifacts in managed job storage, not evaluation reports or arbitrary filesystem links. A cache cleanup must not silently remove retained review evidence. Establish a simple retention policy before enabling cleanup.
- [x] Test OCR-only, fresh accepted/rejected VL, cached VL, missing images and failed calls. Review records never force human approval or add warnings to printed invoices.

All 190 tests pass. The real 20-PDF worker run retains 20 OCR documents and 6 exact cached-model inputs; 3 invoices have model contributions and 17 do not. All invoice values/styles and reference scores are unchanged. Evidence ownership, image corruption/missing paths, fresh/cache/error outcomes and save/restart preservation are tested. See [Stage 4 details and limits](pipeline_stage4.md).

### Stage 5 — read-only admin dashboard

- [x] Overview: scanner/worker/Ollama health separately, last scan/heartbeat, active stage/page and elapsed time, queued/running/waiting-to-save/completed/failed counts, and completed jobs with issues. Report stale telemetry as unknown/offline rather than implying the invoice is still processing.
- [x] Jobs: search/filter by filename, invoice number, date, status and issues; show total/history and today's counts with clear definitions, pagination and output links. Separate job counts from retry-attempt counts.
- [x] Job detail: source PDF, generated invoice download, extracted header/goods summary, stage timeline, errors/warnings, source method, model/cache details, and source/crop comparison. Show the attempt and template/rate version used.
- [x] Evidence view: OCR reading, exact model-input image, structured answer, accepted result/rejection reason and source-page link. Review remains optional and does not block automatic invoice generation.
- [x] System view: watched/output folders, template, active model/settings, component versions and dependency/disk status. Reuse available model timing; only add a genuine completion ETA after measured history supports it. Stage elapsed time is available first.
- [x] Auto-refresh small status endpoints. Heavy PDF/model processing stays outside web requests. Serve files by authorized job/artifact IDs, validate paths and escape source/model text. Do not expose raw arbitrary paths, stack traces or all cache files.
- [x] Verify that the dashboard remains responsive during a long model request and clearly shows the difference between web availability, worker liveness and actual stage progress.

All 203 tests pass. The worker completed all 20 PDFs during live HTTP polling (83 requests; median 16 ms, maximum 406 ms). All 20 job pages, PDF/Excel downloads and 6 model images passed 94 HTTP checks without changing database bytes. Invoice contents/styles/reference scores and 81 protected files are unchanged. See [Stage 5 operation and limits](pipeline_stage5.md).

### Stage 6 — small, safe admin controls

- [x] Pause/resume queue consumption. Pausing does not kill the current model call; new arrivals may continue to queue. State the behavior clearly in the UI.
- [x] Retry selected failed jobs and waiting-to-save publications. A deliberate reprocess creates a new attempt and records which source/configuration it used; preserve earlier results.
- [x] Make commands transactional and idempotent so double-clicks cannot launch duplicate work. Use POST and request protection for mutations even on localhost.
- [x] Provide validated, persistent model, scan, vision limits/timeout and incoming/output settings on System. Apply changes only while scanner/worker are idle; preserve recorded historical destinations and fixed state/artifact roots. Do not expose arbitrary shell commands or stop the user's Excel/Ollama processes.
- [x] Keep forced active-job cancellation deferred. Clear data now provides an explicit, confirmed workspace reset with a recovery archive and automatic reprocessing of remaining inbox PDFs; it is tested separately from per-job retry.
- [x] Add manual invoice editing/additions, canonical download names, local Excel preview and Clear data on the main System page. These later user-requested additions reuse the existing worker, versioning and guarded command flow.

### Stage 7 — Windows background operation

- [x] Provide install/start/stop/status/uninstall through run_system.py and hidden current-user sign-in startup via native Task Scheduler.
- [x] Select the current user, production folders and absolute working directory; verify model/cache/folder access through a real background PDF run. Post-reboot Ollama verification remains Stage 8.
- [x] Enable native periodic crash recovery, launch-failure restart and single-instance protection. Browser-independent execution and existing distinct queue/component/dependency states are retained.
- [x] Preserve generation allowances. Native graceful-stop control drains current work; forced termination uses existing interrupted-attempt recovery. No scheduler execution-time limit is imposed.
- [x] Rotate background logs under ignored runtime state and document coordinated database/artifact/output backup and restore.

### Stage 8 — release gate

- [ ] Run all existing regression tests plus focused queue/intake/recovery/evidence/UI tests introduced at each stage.
- [ ] Process the full BD set through the watcher; preserve existing invoice facts and shared-template styling, with no expected files available to runtime conversion.
- [ ] Exercise fresh OCR and unseen/renamed PDFs, not only warm caches. Verify no duplicate publication after restart, copy completion and lock recovery.
- [ ] Verify model-unavailable and rejected-answer cases are visible in administration while supported invoice values remain usable. No invented completeness/accuracy score or human-intervention text is added to invoices.
- [ ] Restart the PC and verify unattended discovery, worker/dependency health and dashboard access under the chosen startup account.
- [ ] Document daily operation, folder handoff, retry/save recovery, retention, backups and rollback. Deploy each stage only after its gate passes.

## Deferred scope

Cloud services, additional OCR/model changes, distributed/multi-worker execution, LAN exposure/authentication, mandatory manual approval, forced active-job cancellation, emails and external notifications remain outside this local pipeline scope. Manual invoice editing and workspace reset/reprocessing were subsequently requested and implemented. India and Jordan folders are reserved; their extraction/templates still require separate validation.

## Current checkpoint — 21 October 2026

Stages 1–7 are implemented. The original plan also includes Stage 8 as a separate final acceptance gate; implementing seven stages does not complete that gate. Current full regression: **282 tests passed**, plus dashboard status JavaScript checks. The clear/reprocess fix is recorded in `reports/clear_reprocess_20261021/`; editable processing/folder settings are verified in `reports/dynamic_settings_20261021/`.

| Stage | Current outcome | Status |
|---|---|---|
| 1 | Configuration, durable SQLite jobs/attempts, migrations and ownership | Implemented |
| 2 | Stable PDF discovery, snapshots, duplicate prevention and changed-file versions | Implemented |
| 3 | One worker, existing converter, collision-safe publication, retry/save and restart recovery | Implemented |
| 4 | OCR/vision/cache provenance, events and exact model-input images | Implemented |
| 5 | Live overview, searchable jobs, details, issues, source/image review and system health | Implemented; UI subsequently simplified and styled |
| 6 | Pause/resume, selected retry/reprocess, save recovery and protected commands | Implemented; editing, Excel preview/download naming and recoverable Clear data added |
| 7 | Current-user Task Scheduler startup, periodic recovery, single-instance protection, graceful stop and rotated logs | Implemented; real reboot acceptance still pending |
| 8 | Final release acceptance on the current build | Pending separate approval |

### Clear data behavior verified now

- [x] Clear job history and archive generated invoices/evidence with a database backup.
- [x] Preserve input PDFs, templates, settings and model/OCR caches.
- [x] Reset intake observations and resume processing; unchanged inbox PDFs automatically pass readiness checks and recreate invoices once.
- [x] Recover observations orphaned by the previous clear implementation without copying PDFs again.
- [x] Keep reset request replay idempotent, refuse active work and roll back a failed folder move.
- [x] Verify the browser reset and real invoice regeneration in the isolated workspace; recover all 20 already-cleared main jobs through the normal scanner. All 20 completed without failures and their workbook content/styles match the archived versions.

### What remains before final acceptance

- [ ] Run the final full BD comparison on the accepted build: PDF-supported fields, goods/quantities, valuation and workbook formatting. Prior stage comparisons remain historical evidence, not a new accuracy score.
- [ ] Test fresh/unseen PDFs with cold OCR/model paths, beyond the existing sample set and warm caches.
- [ ] Repeat the end-to-end failure matrix on the release candidate: copy interrupted mid-file, duplicate arrivals, Excel locks, process interruption/restart, unavailable/rejected model responses and consistent recovery.
- [ ] Coordinate a real sign-out/reboot and verify automatic startup, Ollama availability, missed-file discovery and browser-independent processing afterward.
- [ ] Exercise the documented backup/restore and clean-machine installation/build process; confirm retention and the intended boundary for Clear data before wider deployment.
- [ ] Obtain approval to begin Stage 8. No sign-out or reboot is performed as part of this fix.

Daily-operation, API/Postman, build, backup and rollback documentation already exists. The remaining work is final verification and acceptance, rather than building another pipeline. The dashboard continues to use the proven scanner/worker state.

